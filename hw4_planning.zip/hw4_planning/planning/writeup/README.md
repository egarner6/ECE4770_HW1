# Project 4: Planning [![tests](../../../badges/submit-proj4/pipeline.svg)](../../../pipelines/submit-proj4/latest)

Replace this with your own writeup! Please place all figures in this directory.

A heuristic function is used to find a minimum cost accumulated across a path from the start node to the final node.
In this situation, the start and final nodes represent the robot's arm in its start and final configurations.

First, I established three variables to represent the final heuristic, and the absolute and minimum costs.
My absolute costs represents the absolute value of the difference between the goal configuration and the current configuration.

Next, the min cost adjusts the absolute costs by two pi when necessary to keep them within range.
This was an important piece of this question as to take into account warping of the joint angles.

Since this is an accumulating function, the heuristic is incremented by the adjusted cost as the function progresses through the path.
If the shape of adjusted cost is 0, then the heuristic returns as the path has been fully cycled through.

Lastly, it was important that the final heuristic was a scalar float, non-negative, and did not overestimate the distance.
These requirements were outlined in the comments of the file to ensure that the heurstic was compliant with the rest of the code.