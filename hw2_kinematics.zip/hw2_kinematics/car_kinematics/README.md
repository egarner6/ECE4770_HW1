Name:

NetID:

Derivation for state update:
