# Project 2: Localization [![tests](../../../badges/submit-proj2/pipeline.svg)](../../../pipelines/submit-proj2/latest)

Replace this with your own writeup! Please place all figures in this directory.

<!-- BEGIN SOLUTION NO PROMPT -->

## TA Information

<!-- END SOLUTION -->
