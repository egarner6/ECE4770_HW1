HW5 ReadMe

Elizabeth Garner (emg229)

PD Tuning:

To tune my parameters, I made both zero and focused just on Kp first.
I slowly increased my Kp until it seemd like each of my tracks looked like they were not improving
with additional increases to my value. Next, I started to increase my Kd. I followed a similar
process as I had done with my Kd. I focused on just the wave trace as it has a variety of curves
and shows issues more clearly than the other traces. One major issue I had with my tuning was
the car's endpoint. For a while, my car was not ending in the proper place so I tuned my 
constants until the car was ending as close to the final spot as the one in the given example
image was.

KT Tuning:

For these constants, I used the estimated ranges given by a TA in office hours. From here, I
adjusted these values to be both larger and smaller to see how they affected the output.
I confinued adjusting the values until the path looked better and better and the code
passed the testcases given.
The saw path is difficult to track because the robot needs to balance looking ahead and 
anticipating what is coming without losing focus on where the robot currently needs to be.
K represents how far ahead the robot should be looking. If it is looking too far ahead, then
the robot will not closely follow its current curve and can either cut its path too short,
for example, if it is along a curve. 
