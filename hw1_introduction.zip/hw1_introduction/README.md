# cs4750_hw
Elizabeth Garner (emg229) submitted on 9/16/2022

1. A node is an executable that completes a process.
    A topic is information sent from the publisher to subscribers.
    A publisher puts out information such as a message to be read by a subscriber.
    A subscriber reads this information by "subscribing" to the publisher.
    
2. A launch file allows multiple nodes to be run in ROS at the same time

3. ![Rviz screenshot](HW1Q3.png)
4. ![runtime_comparison](runtime_comparison.png)
5. ![locations for figure 8](figure8location.png)
    ![norms for figure 8](figure8norms.png)
6. ![locations for crown](crownlocations.png)
    ![norms for crown](crownnorms.png)